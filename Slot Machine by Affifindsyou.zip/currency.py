


def failcash():
            with open("currency1.py", "w+") as file:
             file.write(str(5000))
             file.close()
            print("You purse has been set back to 5000$")




def no_money():
    reset = ""
    secret_word = "reset"


    while reset != secret_word:
        reset = input("No money left!!!! You lose!!! Type 'reset' if you want to play again! : ")
        if reset == "reset":
            failcash()










