

# This project is made by Affifindsyou ! Enjoy my very first Python Project :) !!!


import random

randoms = ["$", "*", "Ψ", "Δ", "¥", "♦", "♥", "♣", "♣", "♣", "♣", "♣", "♠", "♠", "♠", "♠", "♠", "7", "7", "7", "♥",
           "♥", "♥", "♥", "♦", "♦", "♦", "♦", "¥", "¥", "Δ", "Δ", "Δ", "Ψ", "*", "♠", "♣", "♥", "♦",



           ]



ran1 = []

n = random.choice(randoms)
ran1.append(n)

ran2 = []

n = random.choice(randoms)
ran2.append(n)

ran3 = []

n = random.choice(randoms)
ran3.append(n)



#--------------------------------

ran4 = []

n = random.choice(randoms)
ran4.append(n)

ran5 = []

n = random.choice(randoms)
ran5.append(n)

ran6 = []

nn = random.choice(randoms)
ran6.append(n)



#----------------------------------


ran7 = []

n = random.choice(randoms)
ran7.append(n)

ran8 = []

n = random.choice(randoms)
ran8.append(n)

ran9 = []

n = random.choice(randoms)
ran9.append(n)
import time

time.sleep(0.5)
print("\033[1;32;1m",ran1, ran2, ran3)
time.sleep(0.5)
print("\033[1;32;1m",ran4, ran5, ran6)
time.sleep(0.5)
print("\033[1;32;1m",ran7, ran8, ran9)




file = open("currency1.py", "r")

nums = file.readlines()
nums = [int(i) for i in nums]
nums.sort()
file.close()


file = open("currency1.py", "w")
for num in nums:
    file.write("%d\n" %num)
file.close()

from math import *
res = num - 100




line11 = 7
if ran1 == ran2 and ran1 == ran3 and ran1 == ["7"]:
    print("\033[1;36;40m","Small JACKPOT in line 1")
    res = num + 1700

if ran4 == ran5 and ran4 == ran6 and ran4 == ["7"]:
    print("\033[1;36;40m","Small JACKPOT in line 2")
    res = num + 1700

if ran7 == ran8 and ran7 == ran9 and ran7 == ["7"]:
    print("\033[1;36;40m","Small JACKPOT in line 3")
    res = num + 1700

if ran1 == ran5 and ran1 == ran9 and ran1 == ["7"]:
    print("\033[1;36;40m","Small JACKPOT in square line 1-5-9")
    res = num + 1700

if ran7 == ran5 and ran7 == ran3 and ran7 == ["7"]:
    print("\033[1;36;40m","Small JACKPOT in square line 7-5-3")
    res = num + 1700

#-------------------------------------------------
if ran1 == ran2 and ran1 == ran3 and ran1 == ["$"]:
    print("\033[1;35;40m","!!!Major JACKPOT!!! with $ in line 1")
    res = num + 20000

if ran4 == ran5 and ran4 == ran6 and ran4 == ["$"]:
    print("\033[1;35;40m","!!!Major JACKPOT!!! with $ in line 2")
    res = num + 20000

if ran7 == ran8 and ran7 == ran9 and ran7 == ["$"]:
    print("\033[1;35;40m","!!!Major JACKPOT!!! with $ in line 3")
    res = num + 20000

if ran1 == ran5 and ran1 == ran9 and ran1 == ["$"]:
    print("\033[1;35;40m","!!!Major JACKPOT!!! with $ in square line 1-5-9")
    res = num + 20000

if ran7 == ran5 and ran7 == ran3 and ran7 == ["$"]:
    print("\033[1;35;40m","!!!Major JACKPOT!!! with $ in square line 7-5-3")
    res = num + 20000

#-------------------------------------------------
if ran1 == ran2 and ran1 == ran3 and ran1 == ["*"]:
    print("\033[1;31;40m","JACKPOT in line 1")
    res = num + 5500

if ran4 == ran5 and ran4 == ran6 and ran4 == ["*"]:
    print("\033[1;31;40m","JACKPOT in line 2")
    res = num + 5500

if ran7 == ran8 and ran7 == ran9 and ran7 == ["*"]:
    print("\033[1;31;40m","JACKPOT in line 3")
    res = num + 5500

if ran1 == ran5 and ran1 == ran9 and ran1 == ["*"]:
    print("\033[1;31;40m","JACKPOT in square line 1-5-9")
    res = num + 5500

if ran7 == ran5 and ran7 == ran3 and ran7 == ["*"]:
    print("\033[1;31;40m","JACKPOT in square line 7-5-3")
    res = num + 5500

#-------------------------------------------------
if ran1 == ran2 and ran1 == ran3 and ran1 == ["Ψ"]:
    print("\033[1;31;40m","JACKPOT with Trident in line 1")
    res = num + 5000

if ran4 == ran5 and ran4 == ran6 and ran4 == ["Ψ"]:
    print("\033[1;31;40m","JACKPOT with Trident in line 2")
    res = num + 5000

if ran7 == ran8 and ran7 == ran9 and ran7 == ["Ψ"]:
    print("\033[1;31;40m","JACKPOT with Trident in line 3")
    res = num + 5000

if ran1 == ran5 and ran1 == ran9 and ran1 == ["Ψ"]:
    print("\033[1;31;40m","JACKPOT with Trident in square line 1-5-9")
    res = num + 5000

if ran7 == ran5 and ran7 == ran3 and ran7 == ["Ψ"]:
    print("\033[1;31;40m","JACKPOT with Trident in square line 7-5-3")
    res = num + 5000

#-------------------------------------------------
if ran1 == ran2 and ran1 == ran3 and ran1 == ["Δ"]:
    print("\033[1;37;40m","WIN with Triangle in line 1")
    res = num + 500

if ran4 == ran5 and ran4 == ran6 and ran4 == ["Δ"]:
    print("\033[1;37;40m","WIN with Triangle in line 2")
    res = num + 500

if ran7 == ran8 and ran7 == ran9 and ran7 == ["Δ"]:
    print("\033[1;37;40m","WIN with Triangle in line 3")
    res = num + 500

if ran1 == ran5 and ran1 == ran9 and ran1 == ["Δ"]:
    print("\033[1;37;40m","WIN with Triangle in square line 1-5-9")
    res = num + 500

if ran7 == ran5 and ran7 == ran3 and ran7 == ["Δ"]:
    print("\033[1;37;40m","WIN with Triangle in square line 7-5-3")
    res = num + 500

#-------------------------------------------------
if ran1 == ran2 and ran1 == ran3 and ran1 == ["¥"]:
    print("\033[1;34;40m","Big WIN with Yen in line 1")
    res = num + 1500

if ran4 == ran5 and ran4 == ran6 and ran4 == ["¥"]:
    print("\033[1;34;40m","Big WIN with Yen in line 2")
    res = num + 1500

if ran7 == ran8 and ran7 == ran9 and ran7 == ["¥"]:
    print("\033[1;34;40m","Big WIN with Yen in line 3")
    res = num + 1500

if ran1 == ran5 and ran1 == ran9 and ran1 == ["¥"]:
    print("\033[1;34;40m","Big WIN with Yen in square line 1-5-9")
    res = num + 1500

if ran7 == ran5 and ran7 == ran3 and ran7 == ["¥"]:
    print("\033[1;34;40m","Big WIN with Yen in square line 7-5-3")
    res = num + 1500





with open("currency1.py", "w+") as file:
   file.write(str(res))
   file.close()

time.sleep(0.5)
print("\033[2;34;1m","You have", res ,"$ left")

from currency import no_money


if res == 0 :
    no_money()







#currency = 5000
#spin = 50
#currency = currency - 50

#print(currency)




#import currency1




#currency2 = (str(currency1 - 50))

#with open("currency1.py", "w+") as file:
   #file.write(str(currency0))
   #file.close()

import currency1

















#with open("currency1.py","w+") as file:
#    file.write(str(currency2))
#    file.close()



















